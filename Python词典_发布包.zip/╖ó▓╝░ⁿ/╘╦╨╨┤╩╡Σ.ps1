# 运行词典.ps1
Write-Host "正在启动Python词典..." -ForegroundColor Green
Write-Host "如果系统询问，请输入 Y 允许执行" -ForegroundColor Yellow
.\Python词典\Python词典.exe